import React,{useState} from 'react'


export default function TextForm(props) {
    
    const [text,setText]=useState('Enter A Value');
    
    const handleUpClick =()=>{
        let newText= text.toUpperCase();
        setText(newText);
        
        
    }
    const handleLowClick = ()=>{
        let newText = text.toLowerCase();
        setText(newText);
    }
    const handleClearClick = ()=>{
        let newText = '';
        setText(newText);
    }
    const handleCopyText =()=>{
        // let text =document.getElementById("myBox");
        // text.select();
        // navigator.clipboard.writeText(text.value);
        //  or
        navigator.clipboard.writeText(text);
    }
        // const handlePasteText =()=>{
        //     let text =document.getElementById("myBox");
        //     console.log("Paste")
        //     text.clipboard.writeText();
        // }
    const handleExtraSpace =()=>{
        let newText=text.split(/[ ]+/);
        setText(newText.join(" "));
    }
    const handleOnChange=(event)=>{
        setText(event.target.value);
    }
    return (
        <>
        <div className="container" style={{color:props.mode==='dark'?'white':'#042743'}} >
            <h1>{props.heading}</h1>
            <div className="mb-3">
                <textarea className="form-control" value={text} onChange={handleOnChange} style={{backgroundColor:props.mode==='dark'?'gray':'white',color:props.mode==='dark'?'white':'#042743'}} id="myBox" rows="5"></textarea>
            </div>
            <button className="btn btn-primary " onClick={handleUpClick}>Convort To UpperCase</button>
            <button className="btn btn-secondary m-2" onClick={handleLowClick}>Convort To LowerCase</button>
            <button className="btn btn-danger m-2" onClick={handleClearClick}>Clear Text</button>
            <button className="btn btn-success m-2" onClick={handleCopyText}>Copy Text</button>
            {/* <button className="btn btn-info m-2" onClick={handlePasteText}>Paste Text</button> */}
            <button className="btn btn-danger m-2" onClick={handleExtraSpace}>Remove Space</button>
        </div>

        <div className="container my-3" style={{color:props.mode==='dark'?'white':'#042743'}}>
            <h1>Your Text Summary</h1>
            <p>{text.split(/\s+/).filter((element)=>{return element.length!==0}).length} words and {text.length} Characters</p>
            <p>{0.008 * text.split(" ").filter((element)=>{return element.length!==0}).length} Minutes Read</p>            <h2>Preview</h2>
            <p>{text}</p>
        </div>
        </>
    )
}
