{/* <div className='right  lg:text-base md:text-sm sm:text-sm grid grid-cols-[59fr_1fr] gap-4 '>
            <div className='lg:text-base md:text-sm sm:text-sm '>
              <div className='bg-blue-700'></div>
              <div>
                <h1 className='font-bold '>Career Counselling</h1>
                <p className='py-3 text-justify'>Navigating the complex pathways of sports and science careers can be challenging.
                  Our foundation provides personalized career counseling and mentorship to empower women with the guidance they need
                  to make informed decisions. Through one-on-one sessions, workshops, and networking events, we help women chart their
                  professional journeys, explore opportunities, and overcome obstacles. By offering tailored support, we aim to ensure
                  that women have the tools and knowledge to succeed in their chosen paths and contribute meaningfully to their respective fields.</p>
              </div>
            </div>
          </div>
          <div className='left'><img src={career} alt="Career" />
          </div> */}